package com.vyoms.whatsapp.model;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(RowMessage.class)
public abstract class RowMessage_ {

	public static volatile SingularAttribute<RowMessage, String> msgSendFlag;
	public static volatile SingularAttribute<RowMessage, String> msgContent;
	public static volatile SingularAttribute<RowMessage, String> msgTicketStatusSend;
	public static volatile SingularAttribute<RowMessage, String> ticketStatus;
	public static volatile SingularAttribute<RowMessage, Integer> mId;
	public static volatile SingularAttribute<RowMessage, String> msgFrom;
	public static volatile SingularAttribute<RowMessage, String> mDate;
	public static volatile SingularAttribute<RowMessage, String> interactionNo;

}

