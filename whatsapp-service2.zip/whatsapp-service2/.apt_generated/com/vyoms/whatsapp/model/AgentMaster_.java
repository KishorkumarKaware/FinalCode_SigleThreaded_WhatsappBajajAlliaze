package com.vyoms.whatsapp.model;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(AgentMaster.class)
public abstract class AgentMaster_ {

	public static volatile SingularAttribute<AgentMaster, String> ruwEmpId;
	public static volatile SingularAttribute<AgentMaster, String> ruwName;
	public static volatile SingularAttribute<AgentMaster, String> telephoneNumber;
	public static volatile SingularAttribute<AgentMaster, String> intermediaryCd;
	public static volatile SingularAttribute<AgentMaster, String> rmmoName;
	public static volatile SingularAttribute<AgentMaster, String> ipartnerUserId;
	public static volatile SingularAttribute<AgentMaster, String> active;
	public static volatile SingularAttribute<AgentMaster, String> login;
	public static volatile SingularAttribute<AgentMaster, String> ilLocation;
	public static volatile SingularAttribute<AgentMaster, String> iPassword;
	public static volatile SingularAttribute<AgentMaster, String> emailAddress;
	public static volatile SingularAttribute<AgentMaster, String> imRmmo;
	public static volatile SingularAttribute<AgentMaster, String> priVerName;
	public static volatile SingularAttribute<AgentMaster, String> ruwSupervisorEmpCode;
	public static volatile SingularAttribute<AgentMaster, String> uwHub;
	public static volatile SingularAttribute<AgentMaster, String> priSubVerName;
	public static volatile SingularAttribute<AgentMaster, Integer> id;
	public static volatile SingularAttribute<AgentMaster, String> ruwSupervisor;
	public static volatile SingularAttribute<AgentMaster, String> imName;
	public static volatile SingularAttribute<AgentMaster, String> status;

}

