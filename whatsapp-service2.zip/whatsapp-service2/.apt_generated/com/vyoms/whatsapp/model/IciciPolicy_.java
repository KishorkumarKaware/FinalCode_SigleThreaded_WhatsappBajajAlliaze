package com.vyoms.whatsapp.model;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(IciciPolicy.class)
public abstract class IciciPolicy_ {

	public static volatile SingularAttribute<IciciPolicy, String> msgSendFlag;
	public static volatile SingularAttribute<IciciPolicy, String> msgTicketStatusSend;
	public static volatile SingularAttribute<IciciPolicy, Integer> mId;
	public static volatile SingularAttribute<IciciPolicy, String> sendPolicyPng;
	public static volatile SingularAttribute<IciciPolicy, String> getNamePinReceived;
	public static volatile SingularAttribute<IciciPolicy, String> planDetailsSend;
	public static volatile SingularAttribute<IciciPolicy, String> msgContent;
	public static volatile SingularAttribute<IciciPolicy, String> planDetails;
	public static volatile SingularAttribute<IciciPolicy, String> planDetailsPdfPath;
	public static volatile SingularAttribute<IciciPolicy, String> ticketStatus;
	public static volatile SingularAttribute<IciciPolicy, String> msgFrom;
	public static volatile SingularAttribute<IciciPolicy, String> getNamePin;
	public static volatile SingularAttribute<IciciPolicy, String> mDate;
	public static volatile SingularAttribute<IciciPolicy, String> interactionNo;
	public static volatile SingularAttribute<IciciPolicy, String> planDetailsTextReceivedFlag;

}

