package com.vyoms.whatsapp.model;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(EmpMaster.class)
public abstract class EmpMaster_ {

	public static volatile SingularAttribute<EmpMaster, String> employeeName;
	public static volatile SingularAttribute<EmpMaster, String> emailAddress;
	public static volatile SingularAttribute<EmpMaster, String> businessGroup;
	public static volatile SingularAttribute<EmpMaster, Integer> employeeId;
	public static volatile SingularAttribute<EmpMaster, String> telephone;
	public static volatile SingularAttribute<EmpMaster, String> vertical;
	public static volatile SingularAttribute<EmpMaster, Integer> id;

}

