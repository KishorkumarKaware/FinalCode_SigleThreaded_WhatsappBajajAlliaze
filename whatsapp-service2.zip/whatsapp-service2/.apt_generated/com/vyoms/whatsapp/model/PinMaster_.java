package com.vyoms.whatsapp.model;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(PinMaster.class)
public abstract class PinMaster_ {

	public static volatile SingularAttribute<PinMaster, String> numCountryCd;
	public static volatile SingularAttribute<PinMaster, String> datStartDt;
	public static volatile SingularAttribute<PinMaster, String> numStateCd;
	public static volatile SingularAttribute<PinMaster, String> datEndDt;
	public static volatile SingularAttribute<PinMaster, String> correctedpincode;
	public static volatile SingularAttribute<PinMaster, Integer> id;
	public static volatile SingularAttribute<PinMaster, String> numVisibility;
	public static volatile SingularAttribute<PinMaster, String> txtPincodeLocality;
	public static volatile SingularAttribute<PinMaster, String> numCitydistrictCd;
	public static volatile SingularAttribute<PinMaster, String> txtCitydistrict;
	public static volatile SingularAttribute<PinMaster, String> txtState;

}

