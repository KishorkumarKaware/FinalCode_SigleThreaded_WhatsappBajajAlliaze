package com.vyoms.whatsapp.model;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(Plan.class)
public abstract class Plan_ {

	public static volatile SingularAttribute<Plan, String> col4;
	public static volatile SingularAttribute<Plan, Integer> id;
	public static volatile SingularAttribute<Plan, String> col2;
	public static volatile SingularAttribute<Plan, String> col3;
	public static volatile SingularAttribute<Plan, String> plan;
	public static volatile SingularAttribute<Plan, String> col1;

}

