package structure;

public class BrowserSetupLocation {

	public static final String CHROME_LOCATION = "C:\\chromedriver_win32\\chromedriver.exe";
	
	public static final String PHANTOM_LOCATION = "D:\\VyomLabs\\Kit\\drivers\\phantomjs.exe";
		
}
