package com.vyoms.whatsapp.type;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class DelTestClass {
	@RequestMapping("/Test")
	public int getResule(){
		return 1;
	}
	
}
