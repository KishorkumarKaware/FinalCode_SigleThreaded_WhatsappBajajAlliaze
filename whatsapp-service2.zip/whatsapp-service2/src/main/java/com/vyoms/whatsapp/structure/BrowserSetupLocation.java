package com.vyoms.whatsapp.structure;

public class BrowserSetupLocation {

	public static final String CHROME_LOCATION = "C:\\chromedriver\\chromedriver.exe";
	
	public static final String PHANTOM_LOCATION = "C:\\phantomjs-2.1.1-windows\\bin\\phantomjs.exe";
	
	//public static final String CHROME_LOCATION = "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe";
		
}
