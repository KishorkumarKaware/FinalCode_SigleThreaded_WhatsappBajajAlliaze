package com.vyoms.whatsapp.util;

public class Constants {

	public static String downloadFilepath = "D:\\ICICI Lumbard Prapti\\ImagePath\\";
	
	public static String downloadTempFilepath = "D:\\ICICI Lumbard Prapti\\";

}
