package com.vyoms.whatsapp.implementation;

public interface WhatsAppImplementation {

	public void userList() throws  Exception;
}
