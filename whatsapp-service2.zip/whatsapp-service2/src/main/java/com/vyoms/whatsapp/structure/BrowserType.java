package com.vyoms.whatsapp.structure;

public class BrowserType {

	public static int CHROME_BROWSER = 1;

	public static int PHANTOM_BROWSER = 0;

}
