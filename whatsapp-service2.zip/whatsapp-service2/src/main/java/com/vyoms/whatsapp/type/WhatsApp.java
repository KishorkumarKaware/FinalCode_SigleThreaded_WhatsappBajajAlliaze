package com.vyoms.whatsapp.type;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.vyom.whatsapp.rest.aduserreset.BajajRestCall;
import com.vyom.whatsapp.rest.aduserreset.aeRestCallADPassrest;
import com.vyom.whatsapp.rest.aduserreset.serviceDeskRestCall;
import com.vyoms.whatsapp.implementation.WhatsAppImplementation;
import com.vyoms.whatsapp.model.AgentMaster;
import com.vyoms.whatsapp.model.EmpMaster;
import com.vyoms.whatsapp.model.PinMaster;
import com.vyoms.whatsapp.model.Policy;
import com.vyoms.whatsapp.service.AgentMasterService;
import com.vyoms.whatsapp.service.EmpMasterService;
import com.vyoms.whatsapp.service.PinMasterService;
import com.vyoms.whatsapp.util.Constants;
import com.vyoms.whatsapp.util.DriverUtility;

public class WhatsApp implements WhatsAppImplementation {

	public static Actions actions;
    public static String message;
	public static int browserType;

	public static WebDriver driver = null;
	WebDriverWait driverWait;

	public static boolean init = false;
	public long SourceIDSeq = 94;// 113;
	public static HashMap<String, String> msgs = null;
	public static boolean inLoop = true;

	public WhatsApp(PinMasterService pinMasterService,
			AgentMasterService agentMasterService,
			EmpMasterService empMasterService) {
		// TODO Auto-generated constructor stub
	}

	public void sendMessage(String title, String msg)
			throws InterruptedException {
		Thread.sleep(1000);
		driver.switchTo().defaultContent();
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("main")));
		WebElement main = (WebElement) driver.findElement(By.id("main"));
		//WebElement messageList = (WebElement) main.findElement(By.className("message-list"));
		WebElement messageList = (WebElement) main.findElement(By.className("_9tCEa"));
		List<WebElement> messages = messageList.findElements(By.className("msg"));
		String lastMessage = null;
		if (messages.size() >= 1) {
			try {
				WebElement message = messages.get(messages.size() - 1);
				WebElement msgLast = message.findElement(By.className("message-text"));
				lastMessage = msgLast.findElements(By.tagName("span")).get(1).getText();
			} catch (Exception e) {
				
				//e.printStackTrace();
			}
		}
		boolean alreadySent = false;
		if (lastMessage != null && removeSpecialCharacter(lastMessage).equals(removeSpecialCharacter(msg))) {
			alreadySent = true;
		}
		if (!alreadySent) {
			WebElement blockCompose = (WebElement) main.findElement(By.className("_3oju3"));
			WebElement inputTextDiv = (WebElement) blockCompose.findElement(By.className("_2bXVy"));
			wait = new WebDriverWait(driver, 15);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"main\"]/footer/div[1]/div[2]/div/div[2]")));
			WebElement inputText = (WebElement) inputTextDiv.findElement(By.xpath("//*[@id=\"main\"]/footer/div[1]/div[2]/div/div[2]"));
			inputText.click();
			inputText.clear();
			inputText.sendKeys(msg.replaceAll("\n", Keys.chord(Keys.SHIFT, Keys.ENTER)));
			// inputText.sendKeys(msg);please wait while we are generating  your
			// quote \n(you shall receive an email for the same )
			WebElement button = (WebElement) blockCompose.findElements(By.tagName("button")).get(1);
			button.click();
			//System.out.println("Sent Message=" + msg);

			
			/* * sendImage(chatTitle.getAttribute("title"),
			 * "C:\\Users\\Home\\Pictures\\Capture1.png", message);
			 * sendDocument(chatTitle.getAttribute("title"),
			 * "C:\\Users\\Home\\Pictures\\Tagsi - Admin Panel\\src\\main\\resources\\test.txt"
			 * );*/
			 

			msgs.put(title, removeSpecialCharacter(msg));
		}
//RSZ3oJ^R6iqGrfn()ZvlDTRq
		//kishor.vengal@automationedge.com
	}

	AgentMasterService agentMasterService;
	public HashMap<String, AgentMaster> agents;
	String downloadFilepath = Constants.downloadFilepath;
	public HashMap<String, EmpMaster> employees;
	EmpMasterService empMasterService;
	public static HashMap<String, Date> lastReply = new HashMap<>();
	public String gTickets;

	public HashMap<String, PinMaster> pinCodes;

	PinMasterService pinMasterService;

	public HashMap<String, Policy> policy;

	protected String rep;

	// Changes for Intermidate Id
	public HashMap<String, String> validIntermediateIds;

	/*
	 * public WhatsApp(PinMasterService pinService, AgentMasterService
	 * agentService, EmpMasterService empService) { //pinMasterService =
	 * pinService; //agentMasterService = agentService; //empMasterService =
	 * empService; }
	 */
	public String downloadImage() throws InterruptedException {
		Thread.sleep(2000);
		driver.switchTo().defaultContent();
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("main")));

		WebElement main = driver.findElement(By.id("main"));
		String result = null;
		List<WebElement> msgs = main.findElements(By.className("image-thumb"));
		WebElement msg = msgs.get(msgs.size() - 1);
		try {
			wait = new WebDriverWait(driver, 15);
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By
					.className("spinner-container")));
			WebElement resultImg = msg.findElement(By.tagName("img"));
			resultImg.click();
			driver.switchTo().defaultContent();
			wait = new WebDriverWait(driver, 15);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By
					.id("app")));
			WebElement app = driver.findElement(By.id("app"));
			WebElement mediaPanelHeader = app.findElement(By
					.className("media-panel-header"));
			WebElement downloadButton = mediaPanelHeader.findElement(By
					.tagName("a"));
			downloadButton.click();
			WebElement closeButton = mediaPanelHeader.findElement(By
					.tagName("button"));
			closeButton.click();
		} catch (Exception e) {
			result = msg.findElement(By.className("message-system-e2e"))
					.findElement(By.className("emojitext")).getText();
			if (result
					.equals("Messages you text to this chat and calls are secured with end-to-end encryption.")) {
				msg = msgs.get(msgs.size() - 2);
				result = msg.findElement(By.className("message-text"))
						.findElements(By.tagName("span")).get(1).getText();
			}
		}
		System.out.println("Message=" + result);
		return result;
	}

	public String getFileName(String filePath) {
		String fileName = new StringBuffer()
				.append(" ")
				.append(filePath.substring(filePath.lastIndexOf("\\") + 1,
						filePath.length())).append(" ").toString();
		return fileName.replaceAll("\\P{Print}", "").trim();
	}

	public String getMessage(String msg) {
		String message = new StringBuffer().append(" ").append(msg).append(" ")
				.toString();
		return message.replaceAll("\\P{Print}", "").trim();
	}

	public void cleanBrowser() {
		String cmd = "Taskkill /IM chromedriver.exe /F";
		try {
			Process p = Runtime.getRuntime().exec(cmd);
		} catch (IOException e) {
			e.printStackTrace();

		}
	}

	public void init(int bType) {
		if (init == false) {
			System.out.println("Startig INIT ");
			// pinCodes = pinMasterService.getListOfPinMaster();
			// agents = agentMasterService.getListOfAgentMaster();
			// Changes for Intermidate Id
			// validIntermediateIds = populateValidIntermidateId(agents);
			// employees = empMasterService.getListOfEmpMaster();
			driver = DriverUtility.getDriver(bType, downloadFilepath);
			actions = new Actions(driver);
			msgs = new HashMap<String, String>();
			policy = new HashMap<>();
			browserType = bType;
			// gTickets=new HashMap<String,String>();
		}
	}

	// Changes for Intermidate Id
	public Boolean isValidIntermediateId(String id) {
		boolean result = false;
		if (validIntermediateIds.containsKey(id))
			result = true;
		return result;
	}

	public String messageReply(String from, String msg) throws Exception {

		String reply = "";
		message=msg;

		from = from.replace("+91", "").replace(" ", "");
		reply = "Hi," + from + "\nWelcome to Bajaj Allianz ChatBot"+"\nPlease type hi to start the conversation";
		// sendMessage(from, reply);
		Pattern agent_Im_Id_pattrn = Pattern.compile("[a-zA-Z]{4}\\d{5}");
		// agent_Im_Id.matcher(msg);
		Matcher agent_Im_Id = agent_Im_Id_pattrn.matcher(msg);
		Pattern intermediateIdPattern = Pattern.compile("(\\d{12})");
		intermediateIdPattern.matcher(msg);
		Pattern.compile("(([A-D]{1}|[a-d]{1})[1-4]{1})|(([A-D]{1}|[a-d]{1})[1-4]{1}[$]{1}[0-9]{1,7})|(([A-D]{1}|[a-d]{1})[1-4]{1}[@]{1}[0-9]{1,5})|(([A-D]{1}|[a-d]{1})[1-4]{1}[$]{1}[0-9]{1,7}[@]{1}[0-9]{1,5})|(([A-D]{1}|[a-d]{1})[1-4]{1}[@]{1}[0-9]{1,5}[$]{1}[0-9]{1,7})");
		from.split(" ");

		if (!policy.containsKey(from)) {

			final Policy addapter = new Policy();
			addapter.setStart(true);
			policy.put(from, addapter);

		}
		/*if (policy.containsKey(from) && policy.get(from).isStart()
				&& msg.equals("1")) {
			// policy.get(from).setOption("1");
			reply = "asdf";

			sendMessage(from, reply);
			policy.get(from).setOption("1");
		} */
		
		if (policy.get(from).isStart() && policy.containsKey(from)&& msg.equalsIgnoreCase("Hi")||msg.equalsIgnoreCase("Hello")||msg.equalsIgnoreCase("Hey")) {
			policy.get(from).setOption("1");
			reply="Greetings! Your Two Wheeler Policy is due for renewal. Do you wish to Renew?";
			sendMessage(from, reply);
			Thread.sleep(7000);
		}else if (policy.get(from).isStart() && policy.containsKey(from) && policy.get(from).getOption() == "1" && (msg.equalsIgnoreCase("Yes")||msg.equalsIgnoreCase("Y")|| msg.equalsIgnoreCase("Yeah") ||msg.equalsIgnoreCase("Yup") )){
			
			sendMessage(from, "Thank You! Please enter your Policy No.");
			policy.get(from).setOption("2");
			Thread.sleep(5000);
			
		}else if (policy.get(from).isStart() && policy.containsKey(from) && policy.get(from).getOption() == "1" && (msg.equalsIgnoreCase("No")||msg.equalsIgnoreCase("N")||msg.equalsIgnoreCase("Nope")||msg.equalsIgnoreCase("NA"))){
			sendMessage(from, "Thank you for connecting to Bajaj Alianze Bot");
			policy.remove(from);
		}
		
		final String policyNo = "([a-zA-Z0-9-]){20}";
		boolean policycheck=Pattern.compile(policyNo).matcher(msg).matches();
		if (policy.get(from).isStart() && policy.get(from).getOption()=="2" && policycheck) {
			
			// REST call
			//System.out.println("test1");
			String response=BajajRestCall.checkPolicy(msg);
			//System.out.println("test2");
			sendMessage(from, response);
			
		}
		
		/*String vpa="[a-zA-Z0-9]+@[a-zA-Z]+";
		boolean vpacheck=Pattern.compile(vpa).matcher(msg).matches();*/
		/*if(vpacheck==true)
		{*/
		if(policy.get(from).isStart() && policy.containsKey(from) && msg.equalsIgnoreCase("sush2506@hdfc"))
		{
			reply="Payment request sent. Please approve.";
			sendMessage(from, reply);
		}
		
		if(policy.get(from).isStart() && policy.containsKey(from)&& (msg.equalsIgnoreCase("Done")|| msg.equals("Accept")||msg.equalsIgnoreCase("ok")))
		{
			reply="Please wait while we verify the transaction."+"\nCongratulations! Policy No. renewed successfully.";
			sendMessage(from, reply);
		}
		/*
		 * else if (policy.get(from).isStart() && policy.containsKey(from) &&
		 * policy.get(from).getOption() == "1" && msg.equals("Yes")) { reply =
		 * "Hi," + from +
		 * "\nPlease wait, I'm resetting your domain account password. ";
		 * 
		 * sendMessage(from, reply); aeRestCallADPassrest aeRequest = new
		 * aeRestCallADPassrest(); String token = aeRequest.getToken(); String
		 * samNameRequestNumber = ""; SourceIDSeq = SourceIDSeq;
		 * samNameRequestNumber = aeRequest.GetSamName(from,
		 * Integer.toString((int) SourceIDSeq), token);
		 * 
		 * policy.get(from).setAeSamRequestNumber(samNameRequestNumber); String
		 * aeSAMName = null; String aeSAMNamePass = null; while (true) { //
		 * Thread.sleep(3000); try { aeSAMName =
		 * aeRequest.getStatus(policy.get(from).getAeSamRequestNumber(), token);
		 * 
		 * } catch (NullPointerException e) { Thread.sleep(2000); } if
		 * (aeSAMName != null) { policy.get(from).setSAMName(aeSAMName); break;
		 * }
		 * 
		 * }
		 * 
		 * if
		 * (!policy.get(from).getSAMName().toString().contains("User not Exist")
		 * && !policy.get(from).getSAMName().isEmpty()) { SourceIDSeq =
		 * SourceIDSeq; System.out.println("Using SamName=" +
		 * policy.get(from).getSAMName()); String samNamePassRequestNumber =
		 * aeRequest.ResetADPassword(policy.get(from).getSAMName(),
		 * Integer.toString((int) SourceIDSeq), token);
		 * 
		 * policy.get(from).setAeSamNamePassRequestNumber(samNamePassRequestNumber
		 * );
		 * 
		 * while (true) { // Thread.sleep(3000); try { aeSAMNamePass =
		 * aeRequest.getStatus(policy.get(from).getAeSamNamePassRequestNumber(),
		 * token);
		 * 
		 * } catch (NullPointerException e) { Thread.sleep(2000); } if
		 * (aeSAMNamePass != null) { break; } } } if
		 * (policy.get(from).getSAMName().toString().equals("User not Exist")) {
		 * reply = "Hi," + from +
		 * "\n I Found your Mobile number is not configured for SAM Account,\nIt was a great experience for me to assist you!\nHave a nice day."
		 * ; sendMessage(from, reply); policy.get(from).setStart(false); //
		 * policy.remove(from);
		 * 
		 * } else {
		 * 
		 * reply = "Hi," + from + "\npassword for request number " +
		 * policy.get(from).getAeSamRequestNumber()
		 * +" & "+policy.get(from).getAeSamNamePassRequestNumber() +
		 * " with sam account name " + policy.get(from).getSAMName() +
		 * " is reseted to " + aeSAMNamePass + "";
		 * 
		 * reply = "Hi," + from + "\n Your Password has been reseted to " +
		 * aeSAMNamePass +
		 * "+\nIt was a great experience for me to assist you!\nHave a nice day."
		 * ; sendMessage(from, reply); policy.get(from).setStart(false); //
		 * policy.remove(from); } }
		 */// Logic of option 2 Start
		/*
		 * if (policy.containsKey(from) && policy.get(from).isStart() &&
		 * msg.equals("2") && !(msg.equalsIgnoreCase("Yes") ||
		 * msg.equalsIgnoreCase("No"))) { policy.get(from).setOption("2"); reply
		 * = "Hi," + from +
		 * "\nHey, Currently, I am in learning phase, so you will get a slight delay in response; kindly cooperate with me.\nDo you want to unlock your Domain login?(Yes/No) "
		 * ;
		 * 
		 * sendMessage(from, reply); } else if (policy.containsKey(from) &&
		 * policy.get(from).isStart() && msg.equals("No") &&
		 * policy.get(from).getOption() == "2") {
		 * policy.get(from).setStart(false); // policy.remove(from); reply =
		 * "Hi," + from + "\nThis is TechBot, I'm virtual Helpdesk in TCPL. " +
		 * "\nPlease Select service request from bellow" +
		 * "\n1. Reset/Change Domain User ID password." +
		 * "\n2. Unlock my Domain User account." +
		 * "\n3. System Issue/ Disk Cleanup" + "\n4. Exit"; sendMessage(from,
		 * reply);
		 * 
		 * } else if (msg.equals("Yes") && policy.get(from).isStart() &&
		 * policy.containsKey(from) && policy.get(from).getOption() == "2") {
		 * reply = "Hi," + from +
		 * "\n  Please wait I am trying to unlock your Domain login ";
		 * 
		 * sendMessage(from, reply); aeRestCallADPassrest aeRequest = new
		 * aeRestCallADPassrest(); String token = aeRequest.getToken(); String
		 * samUnlockRequestNumber = ""; SourceIDSeq = SourceIDSeq;
		 * samUnlockRequestNumber = aeRequest.GetSamlockState(from,
		 * Integer.toString((int) SourceIDSeq), token);
		 * 
		 * policy.get(from).setAeSamUnlockRequestNumber(samUnlockRequestNumber);
		 * String samUnlockRequestResult = null; String aeSAMNamePass = null;
		 * while (true) { // Thread.sleep(3000); try { samUnlockRequestResult =
		 * aeRequest.getStatus(policy.get(from).getAeSamUnlockRequestNumber(),
		 * token);
		 * 
		 * } catch (NullPointerException e) { Thread.sleep(2000); } if
		 * (samUnlockRequestResult != null) {
		 * policy.get(from).setSamUnlockRequestResult(samUnlockRequestResult);
		 * break; }
		 * 
		 * } try { if
		 * (policy.get(from).getSamUnlockRequestResult().toString().equals
		 * ("User is already Unlocked.")) { reply = "Hi," + from +
		 * "\n I Found your SAM Account is not Lock state.\nIt was a great experience for me to assist you!\nHave a nice day."
		 * ; sendMessage(from, reply); policy.get(from).setStart(false); //
		 * policy.remove(from);
		 * 
		 * } if (policy.get(from).getSamUnlockRequestResult().toString().equals(
		 * "Unlocked.")) { reply = "Hi," + from +
		 * "\nYour SAM Account is Unlocked Now you can login with your existing password.\nIt was a great experience for me to assist you!\nHave a nice day."
		 * ; sendMessage(from, reply); policy.get(from).setStart(false); //
		 * policy.remove(from);
		 * 
		 * } } catch (NullPointerException e) { // TODO Auto-generated catch
		 * block // e.printStackTrace();
		 * 
		 * } }
		 */// login for case 3

		/*
		 * final String ipAddressPattern = [a-z][A-Z][0-9]{10} ;
		 * "^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
		 * "([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
		 * "([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
		 * "([01]?\\d\\d?|2[0-4]\\d|25[0-5])$"; boolean ipAddress =
		 * Pattern.compile(ipAddressPattern).matcher(msg.replaceAll("\\s",
		 * msg)).matches(); if (policy.containsKey(from) &&
		 * policy.get(from).isStart() && policy.get(from).getOption() == "3" &&
		 * ipAddress) { reply = "Hi," + from +
		 * "\nPlease wait I am working on your request"; sendMessage(from,
		 * reply);
		 * 
		 * String diskCleanupResult = null; aeRestCallADPassrest aeRequest = new
		 * aeRestCallADPassrest(); String token = aeRequest.getToken();
		 * 
		 * String aeRequestNo =
		 * aeRequest.diskCleanupState(Integer.toString((int) SourceIDSeq),
		 * token, msg);
		 * 
		 * while (true) { // Thread.sleep(3000); try { // diskCleanupResult = //
		 * aeRequest.diskCleanupState(Integer.toString((int) // SourceIDSeq),
		 * token, msg); diskCleanupResult = aeRequest.getStatus(aeRequestNo,
		 * token);
		 * 
		 * } catch (NullPointerException e) { Thread.sleep(2000); } if
		 * (diskCleanupResult != null) { //
		 * policy.get(from).setSamUnlockRequestResult(diskCleanupResult); break;
		 * }
		 * 
		 * }
		 * 
		 * if (policy.get(from).getSamUnlockRequestResult().toString().contains(
		 * "Unable to connect to server")) {
		 * 
		 * serviceDeskRestCall serviceDeskCall = new serviceDeskRestCall();
		 * serviceDeskCall.addNewRequest(msg);
		 * 
		 * reply = "Hi," + from +
		 * "\nYour IP adress is not reachable. Your request has been logged into a service desk.\nThank you for connecting to TechBot."
		 * ; sendMessage(from, reply); policy.get(from).setStart(false); //
		 * policy.remove(from);
		 * 
		 * }
		 * 
		 * if (diskCleanupResult != null) { reply = "Hi," + from +
		 * "\nYour request is procced successfull"; sendMessage(from, reply); }
		 * 
		 * } if (policy.containsKey(from) && policy.get(from).isStart() &&
		 * !ipAddress && msg.equals("3")) { policy.get(from).setOption("3");
		 * reply = "Hi, " + from + " Please enter your ip address ";
		 * sendMessage(from, reply); }
		 */

		// ********* Login For case 4 (Exit) **********

		/*
		 * if (policy.containsKey(from) && policy.get(from).isStart() &&
		 * msg.equals("4")) { reply =
		 * "Thank you from connection to TechBot. You are successfully exited.";
		 * sendMessage(from, reply); policy.get(from).setStart(false); //
		 * policy.remove(from); }
		 */

		/*
		 * final String ipAddressPattern =
		 * "^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
		 * "([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
		 * "([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
		 * "([01]?\\d\\d?|2[0-4]\\d|25[0-5])$";
		 * 
		 * if(policy.containsKey(from) && policy.get(from).isStart() &&
		 * msg.equals("3")){ policy.get(from).setOption("3"); reply = "Hi," +
		 * from +
		 * "\nHey, Currently, I am in learning phase, so you will get a slight delay in response; kindly cooperate with me.\nPlease Enter your IP address"
		 * ; sendMessage(from, reply); msg=msg.replaceAll("\\s", msg); } else if
		 * (Pattern.compile(ipAddressPattern).matcher(msg).matches() &&
		 * policy.get(from).isStart() && policy.containsKey(from) &&
		 * policy.get(from).getOption() == "3"){
		 * 
		 * reply = "Hi," + from + "\nPlease wait I am working on your request";
		 * sendMessage(from, reply);
		 * 
		 * String diskCleanupResult =""; aeRestCallADPassrest aeRequest = new
		 * aeRestCallADPassrest(); String token = aeRequest.getToken();
		 * 
		 * SourceIDSeq = SourceIDSeq ;
		 * aeRequest.diskCleanupState(Integer.toString((int) SourceIDSeq),
		 * token);
		 * 
		 * while (true) { // Thread.sleep(3000); try { diskCleanupResult =
		 * aeRequest.diskCleanupState(Integer.toString((int) SourceIDSeq),
		 * token);
		 * 
		 * } catch (NullPointerException e) { Thread.sleep(2000); } if
		 * (diskCleanupResult != null) {
		 * //policy.get(from).setSamUnlockRequestResult(diskCleanupResult);
		 * break; }
		 * 
		 * }
		 * 
		 * if (diskCleanupResult != null) { reply = "Hi," + from +
		 * "\nYour request is procced successfull"; sendMessage(from, reply); }
		 * 
		 * 
		 * }else if(!Pattern.compile(ipAddressPattern).matcher(msg).matches() &&
		 * policy.get(from).isStart() && policy.containsKey(from) &&
		 * policy.get(from).getOption() == "3"){ reply = "Hi," + from +
		 * "\n This IP address is not correct. Please enter a valid IP address";
		 * sendMessage(from, reply);
		 * 
		 * }
		 */

		else {
			// reply="Invalid Option\n"+reply;
			if (!policy.containsKey(from)) {
				sendMessage(from, reply);
			}
			
		}

		return removeSpecialCharacter(reply);
	}

	public String readLastMessage() throws InterruptedException {
		Thread.sleep(2000);
		driver.switchTo().defaultContent();
		WebElement main = driver.findElement(By.id("main"));
		String result = null;
		List<WebElement> msgs = main.findElements(By.className("message-list"));
		WebElement msg = msgs.get(msgs.size() - 1);
		try {
			result = msg.findElement(By.className("message-text"))
					.findElements(By.tagName("span")).get(1).getText();
		} catch (Exception e) {
			result = msg.findElement(By.className("message-system-e2e"))
					.findElement(By.className("emojitext")).getText();
			if (result
					.equals("Messages you text to this chat and calls are secured with end-to-end encryption.")) {
				msg = msgs.get(msgs.size() - 2);
				result = msg.findElement(By.className("message-text"))
						.findElements(By.tagName("span")).get(1).getText();
			}
		}
		System.out.println("Message=" + result);
		return result;
	}

	public String removeSpecialCharacter(String temp) {
		try {
			return temp.replaceAll("\\P{Print}", "").trim();
		} catch (Exception e) {
			return temp;
		}
	}

	public void sendDocument(String title, String docPath)
			throws InterruptedException {
		driver.switchTo().defaultContent();
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("main")));
		WebElement main = driver.findElement(By.id("main"));
		WebElement chatControl = main.findElement(By
				.className("pane-chat-controls"));
		List<WebElement> items = chatControl.findElements(By
				.className("menu-item"));
		WebElement attachment = items.get(1).findElement(By.tagName("button"));
		attachment.click();

		WebElement docAttachment = items.get(1)
				.findElements(By.tagName("input")).get(1);
		docAttachment.sendKeys(docPath);

		wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By
				.className("drawer-body")));
		WebElement drawerBody = driver.findElement(By.className("drawer-body"));

		wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By
				.className("drawer-controls")));
		WebElement textButton = drawerBody.findElement(
				By.className("drawer-controls")).findElement(
				By.tagName("button"));
		textButton.click();

	}

	public void sendImage(String title, String imgPath, String msg)
			throws InterruptedException {
		driver.switchTo().defaultContent();
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("main")));
		WebElement main = driver.findElement(By.id("main"));
		WebElement chatControl = main.findElement(By
				.className("pane-chat-controls"));
		List<WebElement> items = chatControl.findElements(By
				.className("menu-item"));
		WebElement attachment = items.get(1).findElement(By.tagName("button"));
		attachment.click();

		WebElement imageAttachment = items.get(1)
				.findElements(By.tagName("input")).get(0);
		imageAttachment.sendKeys(imgPath);

		wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By
				.className("drawer-body")));
		WebElement drawerBody = driver.findElement(By.className("drawer-body"));

		wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By
				.className("input-wrapper")));

		WebElement inputWrapper = drawerBody.findElement(By
				.className("input-wrapper"));
		WebElement inputEmoji = drawerBody.findElement(By
				.className("input-emoji"));
		WebElement inputText = inputEmoji.findElement(By.tagName("div"));
		inputWrapper.click();
		inputText.sendKeys(msg);

		WebElement textButton = drawerBody.findElement(
				By.className("drawer-controls")).findElement(
				By.tagName("button"));
		textButton.click();

	}

	@Override
	public void userList() throws Exception {
		if (driver == null) {
			WhatsApp.driver = DriverUtility.getDriver(browserType, downloadFilepath);
			init = false;
		}
		if (init == false) {
			driver.get("https://web.whatsapp.com/");
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("side")));
			init = true;
		}
		inLoop=false;
		if (inLoop == false) {
			inLoop = true;

			driver.switchTo().defaultContent();
			WebElement side = (WebElement) driver.findElement(By.id("side"));
			WebElement paneSide = (WebElement) side.findElement(By.id("pane-side"));
			List<WebElement> chats = paneSide.findElements(By.className("_2wP_Y"));// ("div")).findElement(By.tagName("div")).findElement(By.tagName("div")).findElements(By.tagName("div"));
			for (WebElement chat : chats) {
				//System.out.println(chats.size());
				//chats = paneSide.findElements(By.className("chat-body"));
				try {
					try {
						actions.moveToElement(chat).click().perform();
						//chat.click();
					} catch (Exception e1) {
						
						chat.click();
						actions.moveToElement(chat).click().perform();
					}
					WebElement chatTitle = chat.findElement(By.className("_25Ooe")).findElement(By.tagName("span"));
					WebElement chatSecondary = chat.findElement(By.className("_1AwDx"))
							.findElement(By.className("_itDl"));//last-msg
					WebElement lastMsg=chatSecondary.findElement(By.className("_2_LEW"));
					String chatUnreadCount = chat.findElement(By.className("_1AwDx"))
							.findElement(By.className("_3Bxar")).findElement(By.tagName("span")).getText();
					if (!chatUnreadCount.equals("") && !msgs.containsKey(chatTitle.getAttribute("title"))) {
						msgs.put(chatTitle.getAttribute("title"),
								removeSpecialCharacter("Old" + lastMsg.getAttribute("title")));
					}
					actions.moveToElement(chat).click().perform();
					
					//System.out.println(chatTitle.getAttribute("title") + "=" + lastMsg.getAttribute("title"));
					WebDriverWait wait = new WebDriverWait(driver, 15);
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("_1AwDx")));
					if (!chatTitle.getAttribute("title").contains(",")) {
						if (processMessage(chatTitle.getAttribute("title"))
								&& msgs.containsKey(chatTitle.getAttribute("title"))) {
							if ((!msgs.get(chatTitle.getAttribute("title")).equals(removeSpecialCharacter(lastMsg.getAttribute("title")))&& removeSpecialCharacter(lastMsg.getAttribute("title")).length()!= 0)||msgs.get(chatTitle.getAttribute("title")).equals(removeSpecialCharacter("Photo"))||msgs.get(chatTitle.getAttribute("title")).equals(removeSpecialCharacter("GIF"))||(msgs.get(chatTitle.getAttribute("title")).contains(removeSpecialCharacter("/"))&& removeSpecialCharacter(lastMsg.getAttribute("title")).length()== 21)) {
								try {
									
									
									/* * System.out.println("Old Message=" +
									 * msgs.get(chatTitle.getAttribute("title"))
									 * + " New Message= " +
									 * lastMsg.getAttribute("title") + " "
									 * +
									 * msgs.get(chatTitle.getAttribute("title"))
									 * .length() + "=" +
									 * removeSpecialCharacter(lastMsg.
									 * getAttribute("title")).length());*/
									 
									System.out.println("Old Message="
											+ msgs.get(chatTitle.getAttribute("title")).length() + " New Message= "
											+ removeSpecialCharacter(lastMsg.getAttribute("title")).length());
									actions.moveToElement(chat).click().perform();
									if (removeSpecialCharacter(lastMsg.getAttribute("title")).equals(
											"â€ªMessages you text to this chat and calls are secured with end-to-end encryption.")) {
										chat.click();
										// Thread.sleep(2000);
									}
									msgs.put(chatTitle.getAttribute("title"),
											removeSpecialCharacter(lastMsg.getAttribute("title")));
									// if
									// (chatTitle.getAttribute("title").contains("pritish"))
									// {
									String a=chatTitle.getAttribute("title");
									try {
										chat.click();
										System.out.println(a);
									} catch (Exception e) {
										
										actions.moveToElement(chat).click().perform();
										chat.click();
										System.out.println(chatTitle.getAttribute("title"));
										e.printStackTrace();
									}
									String message = messageReply(chatTitle.getAttribute("title"),
											removeSpecialCharacter(lastMsg.getAttribute("title")));
									message=message.replace("*", "");
									
									lastReply.put(chatTitle.getAttribute("title"), new Date());
									Thread.sleep(1000);
									if(!removeSpecialCharacter(lastMsg.getAttribute("title")).equals("Photo")&&!removeSpecialCharacter(lastMsg.getAttribute("title")).equals("GIF")&&!(removeSpecialCharacter(lastMsg.getAttribute("title")).contains("/")&&removeSpecialCharacter(lastMsg.getAttribute("title")).length()==21)){
										WebElement archi = driver.findElement(By.xpath("//*[@id='pane-side']/div/div/div/div/div/div/div/div[2]"));////*[@id="pane-side"]/div/div/div/div/div/div/div/div[2]
										WebElement archTitle = archi.findElement(By.xpath("//*[@id='pane-side']/div/div/div/div/div/div/div/div[2]/div[1]/div[1]/span"));////*[@id="pane-side"]/div/div/div/div/div/div/div/div[2]/div[1]/div[1]/span
										System.out.println(a.equals(archTitle.getText().toString().trim()));
										System.out.println(chatTitle.getAttribute("title").toString().trim());
										System.out.println(archTitle.getText().toString().trim());
										if(a.equals(archTitle.getText().toString().trim())){
										actions.moveToElement(archi).click().perform();
										archi.click();
										actions.contextClick(archi).build().perform();
										wait.until(ExpectedConditions.visibilityOfElementLocated((By.className("_3s1D4"))));
										WebElement arch = driver.findElement(By.className("_3s1D4"));
										List<WebElement> archive = arch.findElements(By.tagName("li"));
										archive.get(0).click();
										}else{
											actions.moveToElement(chat).click().perform();
											chat.click();
											actions.contextClick(chat).build().perform();
											wait.until(ExpectedConditions.visibilityOfElementLocated((By.className("_3s1D4"))));
											WebElement arch = driver.findElement(By.className("_3s1D4"));
											List<WebElement> archive = arch.findElements(By.tagName("li"));
											archive.get(0).click();
										}
										
									}
										
									
									/* * sendImage(chatTitle.getAttribute("title")
									 * ,
									 * "C:\\Users\\Home\\Pictures\\Capture1.png",
									 * message);
									 * sendDocument(chatTitle.getAttribute(
									 * "title"),
									 * "C:\\Users\\Home\\Pictures\\Tagsi - Admin Panel\\src\\main\\resources\\test.txt"
									 * );*/
									 
									chatTitle = chat.findElement(By.className("chat-main"))
											.findElement(By.className("chat-title")).findElement(By.tagName("span"));
									lastMsg = chat.findElement(By.className("_1AwDx"))
											.findElement(By.className("_itDl"));
									// msgs.put(chatTitle.getAttribute("title"),
									// message);
								} catch (Exception e) {
									
									e.printStackTrace();
								}
								// }

							}else{
								if(!removeSpecialCharacter(lastMsg.getAttribute("title")).equals("Photo")&&!removeSpecialCharacter(lastMsg.getAttribute("title")).equals("GIF")&&!(removeSpecialCharacter(lastMsg.getAttribute("title")).contains("/")&&removeSpecialCharacter(lastMsg.getAttribute("title")).length()==21)){
									actions.contextClick(chat).build().perform();
									wait.until(ExpectedConditions.visibilityOfElementLocated((By.className("_2uLFU"))));
									WebElement arch = driver.findElement(By.className("_2uLFU"));
									List<WebElement> archive = arch.findElements(By.linkText("Archive chat"));
									archive.get(0).click();
								}
							}
						} else {
							actions.moveToElement(chat).click().perform();
							if (removeSpecialCharacter(lastMsg.getAttribute("title")).equals(
									"â€ªMessages you text to this chat and calls are secured with end-to-end encryption.")) {
								chat.click();
								// Thread.sleep(2000);
							}
							System.out.println(
									"Length=" + removeSpecialCharacter(lastMsg.getAttribute("title")).length());
							if (removeSpecialCharacter(lastMsg.getAttribute("title")).length() > 0) {
								msgs.put(chatTitle.getAttribute("title"),
										removeSpecialCharacter(lastMsg.getAttribute("title")));
								
								lastReply.put(chatTitle.getAttribute("title"), new Date());
								System.out.println("Starting Message=" + chatTitle.getAttribute("title") + " "
										+ removeSpecialCharacter(lastMsg.getAttribute("title")));
							}
							messageReply(chatTitle.getAttribute("title"),
									removeSpecialCharacter(lastMsg.getAttribute("title")));
								WebElement archi = driver.findElement(By.xpath("//*[@id='pane-side']/div/div/div/div[1]/div/div/div[2]"));
								actions.moveToElement(archi).click().perform();
								chat.click();
								
								actions.contextClick(archi).build().perform();
								wait.until(ExpectedConditions.visibilityOfElementLocated((By.className("_2uLFU"))));
								WebElement arch = driver.findElement(By.className("_2uLFU"));
								List<WebElement> drop = arch.findElements(By.tagName("li"));
								try {
									drop.get(0).click();
									
								} catch (Exception e) {
									
									e.printStackTrace();
								}
								
							
							
							
						}
					}
				} catch (Exception e) {
					
					e.printStackTrace();
				}
			}
			inLoop = false;
		}

		Thread.sleep(1500);
		//userList();
	}

	public boolean processMessage(String key) {
		Date d1 = lastReply.get(key);
		if (d1 == null)
			return true;
		Date d2 = new Date();
		long seconds = (d2.getTime() - d1.getTime()) / 1000;
		if (seconds > 1) {
			return true;
		}
		return false;
	}

}
