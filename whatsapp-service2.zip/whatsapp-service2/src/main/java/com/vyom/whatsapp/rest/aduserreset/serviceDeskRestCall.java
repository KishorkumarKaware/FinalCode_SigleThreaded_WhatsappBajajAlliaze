package com.vyom.whatsapp.rest.aduserreset;

import java.io.IOException;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

import org.json.JSONObject;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class serviceDeskRestCall {

	//private final String apiKey = "8AE6C938-1B61-40AF-AC09-70B7889500F4";

	//private final String urlRaiseRequest = "http://localhost:9191/sdpapi/request?OPERATION_NAME=ADD_REQUEST&TECHNICIAN_KEY="+ apiKey;

	public static void main(String[] args) throws IOException {
		serviceDeskRestCall obj = new serviceDeskRestCall();
		// System.out.println( obj.addNewRequest("test"));
		obj.addNewRequest("test");

	}

	public void addNewRequest(String subject) throws IOException {

		String RequestJSON = "{" 
				+ "\"operation\": {" 
				+ "\"details\": {" 
				+ "\"requester\": \"AutomationEdge\","
				+ "\"subject\": \"AE - IP Address not reachable\","
				+ "\"description\": \"Disk cleanup request for ip address \"" + subject + ","
				+ "\"requesttemplate\": \"Unable to browse\"," 
				+ "\"priority\": \"High\"," 
				+ "\"site\": \"New York\","
				+ "\"group\": \"Network\"," 
				+ "\"technician\": \"Howard Stern\"," 
				+ "\"level\": \"Tier 3\","
				+ "\"status\": \"open\"," 
				+ "\"service\": \"Email\"" 
				+ "}" 
				+ "}" 
				+ "}";

		System.out.println(RequestJSON);

		OkHttpClient client = new OkHttpClient();

		Request request = new Request.Builder()
				.url("http://localhost:9191/sdpapi/request?OPERATION_NAME=ADD_REQUEST&TECHNICIAN_KEY=E42099FE-EB94-437E-A09E-DC7E4E6E8B95&format=json&INPUT_DATA="
						+ RequestJSON)
				.addHeader("cache-control", "no-cache")
				.build();

		Response response = client.newCall(request).execute();
		System.out.println(response.body().string());

	}
}
