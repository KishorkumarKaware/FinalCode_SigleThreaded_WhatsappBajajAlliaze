package com.vyom.whatsapp.rest.aduserreset;

import java.io.IOException;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import com.vyoms.whatsapp.*;
import com.vyoms.whatsapp.type.WhatsApp;

public class BajajRestCall {
	
	/*public static void main(String[] args) throws Exception {
		System.out.println(checkPolicy("OG172303180200011493"));
		//checkPolicy();
		
	}*/
	
	public static String checkPolicy(String policyNo) throws Exception{
		String json="";	
	MediaType mediaType = MediaType.parse("application/json");
	OkHttpClient client = new OkHttpClient();
	RequestBody body = RequestBody.create(mediaType, "");
	
	Request request = new Request.Builder()
	  .url("http://webservicesdev.bajajallianz.com/BjazRnwPolData/getRnwData?pol_ref="+policyNo)
	  .post(body)
	  .addHeader("cache-control", "no-cache")
	  .addHeader("postman-token", "0c0dceae-09fe-a272-ddd9-52ff8855f295")
	  .build();
	
	Response response = client.newCall(request).execute();
	//System.out.println("body"+response);
	/*String json=response.body().string();
	if(json.contains("Kindly enter valid BAJAJ POLICY NUMBER ($#POL_NO#$)"))
	{
		return "Kindly enter valid BAJAJ POLICY NUMBER ($#POL_NO#$)";
		//System.out.println("Kindly enter valid BAJAJ POLICY NUMBER ($#POL_NO#$)");
		
	}
	else if(json.contains("Policy Data is Valid"))
	{
		return "Policy Data is Valid";
		//System.out.println("Policy Data is Valid");
	}*/
  //WhatsApp.message;
	//System.out.println(response.body().string());
	json=response.body().string();
	
	ObjectMapper mapper1 = new ObjectMapper();
    JsonNode actualObj = mapper1.readTree(json);
    String jsonNode1 = (actualObj.get("grosspremium").toString());
  
    jsonNode1=jsonNode1.replace("\"", "");
    System.out.println("jsonNode1: "+jsonNode1);
    //actualObj = mapper1.readTree(jsonNode1);
    
    System.out.println("Gross_Premium: "+jsonNode1);
    
	 
	
	System.out.println(json);
	if (json.contains("Kindly enter valid BAJAJ POLICY NUMBER ($#POL_NO#$)")|| json.contains("Invalid policy number")||json.contains("Please Enter Valid Policy Number")) {
		
		return "Kindly enter valid BAJAJ POLICY NUMBER";
		
	}else if (json.contains("Policy Data is Valid")|| json.contains("Policy Validate Successfully")){
		return "Valid Policy No. Your Policy renewal premium is Rs."+jsonNode1+" "+"\nPlease share your UPI ID to make payment";
	}
	
	else{
	
	return "Please Enter Valid Policy Number";
	}
	
	
	}

}
